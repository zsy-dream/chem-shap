﻿import matplotlib
matplotlib.use('Agg')

from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_cors import CORS
from config import Config

db = SQLAlchemy()
login_manager = LoginManager()

def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)
    
    # 启用CORS
    CORS(app, resources={r"/api/*": {"origins": "*"}})
    
    db.init_app(app)
    login_manager.init_app(app)
    login_manager.login_view = 'web.login'
    
    # 配置日志
    from app.utils.logger import setup_logger
    setup_logger(app)
    
    # 注册蓝图
    from app.routes import auth, data, model, analysis, report, health, web
    app.register_blueprint(auth.bp)
    app.register_blueprint(data.bp)
    app.register_blueprint(model.bp)
    app.register_blueprint(analysis.bp)
    app.register_blueprint(report.bp)
    app.register_blueprint(health.bp)
    app.register_blueprint(web.bp)
    
    # 注册错误处理器
    register_error_handlers(app)
    
    # 注册请求钩子
    register_request_hooks(app)
    
    # 注册CLI命令
    from app.cli import register_commands
    register_commands(app)
    
    return app

def register_error_handlers(app):
    """注册错误处理器"""
    from flask import jsonify, render_template, request
    from werkzeug.exceptions import HTTPException

    def _wants_json():
        path = request.path or ''
        if path.startswith('/api/'):
            return True
        accept = request.headers.get('Accept', '')
        if 'application/json' in accept.lower():
            return True
        return False

    def _render_error_page(code, title, description, message=None):
        return render_template(
            'error.html',
            code=code,
            title=title,
            description=description,
            message=message
        ), code
    
    @app.errorhandler(400)
    def bad_request(error):
        if _wants_json():
            return jsonify({'error': '请求参数错误', 'message': str(error)}), 400
        return _render_error_page(400, '请求参数错误', '请求参数不符合预期，请检查输入后重试。', str(error))
    
    @app.errorhandler(401)
    def unauthorized(error):
        if _wants_json():
            return jsonify({'error': '未授权，请先登录'}), 401
        return _render_error_page(401, '未授权', '当前页面需要登录后访问，请重新登录。')
    
    @app.errorhandler(403)
    def forbidden(error):
        if _wants_json():
            return jsonify({'error': '权限不足'}), 403
        return _render_error_page(403, '权限不足', '你没有权限访问该资源。')
    
    @app.errorhandler(404)
    def not_found(error):
        if _wants_json():
            return jsonify({'error': '资源未找到'}), 404
        return _render_error_page(404, '资源未找到', '你访问的页面不存在，可能已被移动或删除。')
    
    @app.errorhandler(405)
    def method_not_allowed(error):
        if _wants_json():
            return jsonify({'error': '方法不允许'}), 405
        return _render_error_page(405, '方法不允许', '请求方法不被允许，请返回并重新操作。', str(error))
    
    @app.errorhandler(413)
    def request_entity_too_large(error):
        if _wants_json():
            return jsonify({'error': '上传文件过大'}), 413
        return _render_error_page(413, '上传文件过大', '上传文件超过限制，请压缩或更换文件后重试。')
    
    @app.errorhandler(429)
    def too_many_requests(error):
        if _wants_json():
            return jsonify({'error': '请求过于频繁'}), 429
        return _render_error_page(429, '请求过于频繁', '请求过于频繁，请稍后再试。')
    
    @app.errorhandler(500)
    def internal_error(error):
        db.session.rollback()
        app.logger.error(f"服务器内部错误: {str(error)}")
        if _wants_json():
            return jsonify({'error': '服务器内部错误'}), 500
        return _render_error_page(500, '服务器内部错误', '系统运行异常，请稍后重试。')
    
    @app.errorhandler(Exception)
    def handle_exception(error):
        # 处理非HTTP异常
        if isinstance(error, HTTPException):
            return error
        
        db.session.rollback()
        app.logger.error(f"未处理的异常: {str(error)}", exc_info=True)
        if _wants_json():
            return jsonify({'error': '服务器内部错误', 'message': str(error)}), 500
        return _render_error_page(500, '服务器内部错误', '系统运行异常，请稍后重试。', str(error))

def register_request_hooks(app):
    """注册请求钩子"""
    from flask import request
    import time
    
    @app.before_request
    def before_request():
        request.start_time = time.time()
    
    @app.after_request
    def after_request(response):
        if hasattr(request, 'start_time'):
            elapsed = time.time() - request.start_time
            app.logger.info(f"{request.method} {request.path} - {response.status_code} - {elapsed:.3f}s")
        return response

